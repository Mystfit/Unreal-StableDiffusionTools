#include "StableDiffusionSequencerModule.h"

void FStableDiffusionSequencerModule::StartupModule() {

}

void FStableDiffusionSequencerModule::ShutdownModule() {

}

IMPLEMENT_MODULE(FStableDiffusionSequencerModule, StableDiffusionSequencer)