#include "StableDiffusionToolsModule.h"

void FStableDiffusionToolsModule::StartupModule() {

}

void FStableDiffusionToolsModule::ShutdownModule() {

}

IMPLEMENT_MODULE(FStableDiffusionToolsModule, StableDiffusionTools)